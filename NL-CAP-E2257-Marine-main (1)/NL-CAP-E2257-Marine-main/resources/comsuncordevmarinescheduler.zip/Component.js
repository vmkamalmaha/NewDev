sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.suncor.dev.marinescheduler.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map