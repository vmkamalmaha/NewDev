sap.ui.define(['sap/ui/core/mvc/ControllerExtension','sap/m/MessageBox'], function (ControllerExtension, MessageBox) {
	'use strict';

	return ControllerExtension.extend('com.suncor.dev.marinescheduler.ext.controller.ObjectPageExtension', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf zdebapp.ext.controller.ObjectPageExtension
			 */
			onInit: function () {
				var x=sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel");
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::StandardAction::SwitchDraftAndActiveObject::_dt").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::InterbookTrades::LineItem::StandardAction::BasicSearch").setVisible(false);
				
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::Trades::LineItem::StandardAction::BasicSearch").setVisible(false);
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				// var oModel = this.base.getExtensionAPI().getModel();
				// this.base.getAppComponent().getRouter().getRoute("OrdersObjectPage").attachPatternMatched(this.base.routing._onPatternMatched, this);
			},
			onAfterRendering: function(){
				var x=sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel");
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::StandardAction::SwitchDraftAndActiveObject::_dt").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::InterbookTrades::LineItem::StandardAction::BasicSearch").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::Trades::LineItem::StandardAction::BasicSearch").setVisible(false);
				
			},
			onPageReady: function(){
				var x=sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel");
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::FooterBar::StandardAction::Cancel").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::StandardAction::SwitchDraftAndActiveObject::_dt").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::InterbookTrades::LineItem::StandardAction::BasicSearch").setVisible(false);
				sap.ui.getCore().byId("com.suncor.dev.marinescheduler::MarineSchedulerHeaderObjectPage--fe::table::Trades::LineItem::StandardAction::BasicSearch").setVisible(false);

				
			},
			editFlow: {
				onBeforeEdit: function (mParameters) {
					debugger;
					//synchronous access to property value
					// if (mParameters?.context.getProperty("DialogProperty")) {
					// 	return this.openDialog("Do you want to edit this really nice... object ?", true);
					// }
				},
				onAfterEdit: function (mParameters) {
					debugger;
					//synchronous access to complete data the context points to
					// return MessageToast.show(
					// 	"Edit successful. Number of data entries in context: " + Object.entries(mParameters.context.getObject()).length
					// );
				},
			},
			routing: {
                
				_onPatternMatched: function () {
					var oReceiptsTable = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::CAF_Receipts::LineItem::CashAccReceiptsSec-innerTable");
					var oPaymentsTable = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::CAF_Payments::LineItem::CashAccPaymentSec-innerTable");
					var oBankingTable = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_Banking::LineItem::Banking-innerTable");
					if (oReceiptsTable) {
						oReceiptsTable.setGrowingThreshold(20);
						oReceiptsTable.attachUpdateFinished(function (oEvent) {
							oEvent.getSource().getBinding('items').sort(new sap.ui.model.Sorter("Field_ID", false));
						});
					}
					if (oPaymentsTable) {
						oPaymentsTable.setGrowingThreshold(20);
						oPaymentsTable.attachUpdateFinished(function (oEvent) {
							oEvent.getSource().getBinding('items').sort(new sap.ui.model.Sorter("Field_ID", false));
						});
					}
					if (oBankingTable) {
						oBankingTable.setGrowingThreshold(20);
						oBankingTable.attachUpdateFinished(function (oEvent) {
							oEvent.getSource().getBinding('items').sort(new sap.ui.model.Sorter("Field_ID", false));
						});
					}

					var oCustomCODTable = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_Customs::LineItem::CustomCod-innerTable");
					oCustomCODTable.addStyleClass("myRedTextButton");
					var oCustomMOTable1 = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_MO_Lines::LineItem::MoIssued-innerTable");
					oCustomMOTable1.addStyleClass("myRedTextButton");
					var oCustomMOTable2 = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_Payments_USDMOPaid::LineItem::UsdPaid-innerTable");
					oCustomMOTable2.addStyleClass("myRedTextButton");
					var oCustomMOTable3 = this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_Payments_CMOPaid_Lines::LineItem::CmoPaid-innerTable");
					oCustomMOTable3.addStyleClass("myRedTextButton");
					var oCustomMOTable4 =this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_OFT_InternationalCourier::LineItem::InternationalCourier-innerTable");
					oCustomMOTable4.addStyleClass("myRedTextButton");
					var oCustomMOTable5 =this.getView().byId("zdebapp::OrdersObjectPage--fe::table::DF_OFT_OriginatingPrepaid::LineItem::OrignatingPrepaid-innerTable");
					oCustomMOTable5.addStyleClass("myRedTextButton");
					//this.getView().byId("zdebapp::OrdersObjectPage--fe::FCLStandardAction::FullScreen").firePress();
				}
			},
			editFlow:{
				onBeforeSave: function (mParameters) {
					return this.openDialog();
				}
			}


		},

		openDialog: function () {
			return new Promise(
				function (resolve, reject) {
					MessageBox.confirm("Are you sure you want to submit/post this form? This action cannot be undone and the form will no longer be editable.", {
						actions: ["Submit", MessageBox.Action.CLOSE],
						emphasizedAction: "Submit",
						onClose: function (sAction) {
							if(sAction=="Submit"){
								resolve(null);
							}else{
								reject(null);
							}
						}
					});
				}.bind(this)
			);
		},
		onbeforeRebindTable: function(oEvent){
			console.log("LOL Obhje");
			this.getView().byId("zdebapp::OrdersObjectPage--fe::FCLStandardAction::FullScreen").firePress();
		}
	});
});
