sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{CreateUpdateNom:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=CustomController.js.map