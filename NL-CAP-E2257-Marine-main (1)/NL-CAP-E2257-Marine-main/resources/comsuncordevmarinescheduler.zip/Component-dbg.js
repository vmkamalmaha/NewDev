sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.suncor.dev.marinescheduler.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);